var request = require("request");

var accountId = 'YOUR_ACCOUNT_ID';
var login_service_tokens = 'YOUR_LOGIN_TOKENS';

// Account emails not to delete
var emailsToKeep = [
  'email@newrelic.com',
  'email@gmail.com'
];

deleteUsers();

function deleteUsers() {  
  var headers = {
    'Accept': 'application/json', 
    'Content-Type': 'application/json',
    'Cookie': 'login_service_login_newrelic_com_tokens=' + login_service_tokens + ';', 
    'Host': 'user-management.service.newrelic.com',
    'Origin': 'https://account.newrelic.com',
    'Referer': 'https://account.newrelic.com/accounts/' + accountId + '/users'
  };

  var options = {
    url: "https://user-management.service.newrelic.com/accounts/" + accountId + "/users",
    method: 'GET',
    headers: headers
  };
  
  request(options, 
    function(error, response, body) {
      if (!error) {
        users = JSON.parse(body);
        users.forEach(function(user) {
          deleteUser(user);
        });
      } else {
        console.log(error);
      }
  });
}

function deleteUser(user) {
  if (emailsToKeep.indexOf(user.email) >= 0) return;
  
  var headers = {
    'Accept': 'application/json', 
    'Content-Type': 'application/json',
    'Cookie': 'login_service_login_newrelic_com_tokens=' + login_service_tokens + ';', 
    'Host': 'rpm.newrelic.com',
    'Origin': 'https://account.newrelic.com',
    'Referer': 'https://account.newrelic.com/accounts/' + accountId + '/users/' + user.user_id,
    'X-Requested-With': 'XMLHttpRequest'  
  };

  var options = {
    url: "https://rpm.newrelic.com/user_management/accounts/" + accountId + "/users/" + user.user_id,
    method: 'DELETE',
    headers: headers
  };

  request(options, 
    function(error, response, body) {
      if (!error) {
        console.log(user.user_id, user.email);
      } else {
        console.log(error);
      }
  });
}